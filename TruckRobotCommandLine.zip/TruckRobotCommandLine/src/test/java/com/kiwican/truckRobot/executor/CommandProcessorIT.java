package com.kiwican.truckRobot.executor;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
class CommandProcessorIT {

    @Autowired
    private CommandProcessor commandProcessor;

    @Test
    public void testSimpleMove () {
        String result = commandProcessor.executeCommands(new String[] {"PLACE", "0,0,NORTH", "MOVE", "REPORT"});
        assertEquals("0,1,NORTH", result);
    }

    @Test
    public void testTurn() {
        String result = commandProcessor.executeCommands(new String[] {"PLACE", "0,0,NORTH", "LEFT", "REPORT"});
        assertEquals("0,0,WEST", result);
    }

    @Test
    public void testMultiple() {
        String result = commandProcessor.executeCommands(new String[] {"PLACE", "1,2,EAST", "MOVE", "MOVE", "LEFT", "MOVE", "REPORT"});
        assertEquals("3,3,NORTH", result);
    }

    @Test
    public void testError() {
        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class, () -> {
            commandProcessor.executeCommands(new String[]{"MOVE", "REPORT"});
        });
    }
}