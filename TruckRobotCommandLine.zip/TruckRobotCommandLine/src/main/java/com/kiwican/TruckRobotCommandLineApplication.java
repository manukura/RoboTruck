package com.kiwican;

import com.kiwican.truckRobot.executor.CommandProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication
public class TruckRobotCommandLineApplication implements CommandLineRunner {

    public static void main(String[] args) {
        new SpringApplicationBuilder(TruckRobotCommandLineApplication.class)
                .web(WebApplicationType.NONE)
                .run(args);
    }

    @Autowired
    private CommandProcessor commandProcessor;

    @Override
    public void run(String... args) {
        try {
            commandProcessor.executeCommands(args);
        } catch (Exception e) {
            System.out.println("ROBOT MISSING");
        }
    }
}
