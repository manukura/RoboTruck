package com.kiwican.truckRobot.executor;

import com.kiwican.truckRobot.model.Link;
import com.kiwican.truckRobot.model.Truck;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

@Component
public class PutExecutor implements CommandExecutor{
    private final RestClient restClient;

    @Autowired
    public PutExecutor(RestClient restClient) {
        this.restClient = restClient;
    }

    @Override
    public String executeCommand(CommandProcessor commandProcessor) {
        Link linkUri = commandProcessor.getCurrentLink();
        Truck result = restClient.put()
                .uri(linkUri.getHref())
                .retrieve()
                .body(Truck.class);

        return null;
    }
}
