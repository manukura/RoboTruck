package com.kiwican.truckRobot.model;

public enum Command {
    PLACE,
    LEFT,
    RIGHT,
    MOVE,
    REPORT
}
