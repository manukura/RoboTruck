package com.kiwican.truckRobot.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

// this class is a hack because spring boot turns off hateos when not a web application
// there is probably a better way
public class LinkedObject {

    @JsonProperty("_links")
    private Map<String, Link> links;

    public Map<String, Link> getLinks() {
        return links;
    }

    public void setLinks(Map<String, Link> links) {
        this.links = links;
    }
}
