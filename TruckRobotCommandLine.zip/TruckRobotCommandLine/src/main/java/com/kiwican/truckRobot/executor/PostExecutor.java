package com.kiwican.truckRobot.executor;

import com.kiwican.truckRobot.model.Truck;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

@Component
public class PostExecutor implements CommandExecutor {

    private final String placeUrl;

    private final RestClient restClient;

    @Autowired
    public PostExecutor(@Value("${place.url}")
                                String placeUrl, RestClient restClient) {
        this.placeUrl = placeUrl;
        this.restClient = restClient;
    }

    @Override
    public String executeCommand(CommandProcessor commandProcessor) {
        if (commandProcessor.getArgs().length < commandProcessor.getCurrentArgIndex() + 1) {
            throw new IllegalArgumentException("Cannot place the robot as there is no coordinates");
        }


        String[] xYDir = commandProcessor.getArgs()[commandProcessor.getCurrentArgIndex() + 1].split(",");
        if (xYDir.length != 3) {
            throw new IllegalArgumentException("Cannot parse the place command");
        }

        Map<String, String> vars = new HashMap<>();
        vars.put("X", xYDir[0]);
        vars.put("Y", xYDir[1]);
        vars.put("DIRECTION", xYDir[2]);
        UriComponentsBuilder uriComponents = UriComponentsBuilder.fromUriString(placeUrl);
        URI uri = uriComponents.build(vars);

        Truck truck = restClient.post()
                .uri(uri)
                .retrieve()
                .body(Truck.class);

        if (null == truck) {
            throw new IllegalStateException("The truck was not created");
        }
        commandProcessor.setCommandLinks(truck.getLinks());

        // update the counter because we took an extra arg
        commandProcessor.setCurrentArgIndex(commandProcessor.getCurrentArgIndex() + 1);
        return null;
    }
}
