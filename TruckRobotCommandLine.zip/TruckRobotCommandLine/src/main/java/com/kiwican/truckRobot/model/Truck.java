package com.kiwican.truckRobot.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.RepresentationModel;

import java.util.Map;
import java.util.Objects;

public class Truck extends LinkedObject {
    private long truckId;
    private Position position;
    private Direction direction;

    public Truck(){
    }

    public Truck(long truckId, Position position, Direction direction) {
        this.truckId = truckId;
        this.position = position;
        this.direction = direction;
    }

    public long getTruckId() {
        return truckId;
    }

    public void setTruckId(long truckId) {
        this.truckId = truckId;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    @Override
    public String toString() {
        return "Truck{" +
                "truckId=" + truckId +
                ", position=" + position +
                ", direction=" + direction +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Truck other = (Truck) o;
        return truckId == other.truckId;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(truckId);
    }

    // commands
    public void move (GridTable gridTable) {
        position = direction.move(position, gridTable);
    }

    public void left () {
        direction = direction.left();
    }

    public void right() {
        direction = direction.right();
    }

    public String report() {
        return String.format("%d,%d,%s", position.x(), position.y(),direction);
    }
}
