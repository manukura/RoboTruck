package com.kiwican.truckRobot.model;

public record Position(int x, int y) {

    public Position move(int deltaX, int deltaY, GridTable factory) {
        return factory.createPosition(x + deltaX, y + deltaY);
    }
}
