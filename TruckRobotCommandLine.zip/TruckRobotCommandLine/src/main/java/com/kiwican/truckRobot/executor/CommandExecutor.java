package com.kiwican.truckRobot.executor;

public interface CommandExecutor {
    String executeCommand(CommandProcessor commandProcessor);
}
