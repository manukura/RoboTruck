package com.kiwican.truckRobot.executor;

import com.kiwican.truckRobot.model.Command;
import com.kiwican.truckRobot.model.Link;

import java.util.HashMap;
import java.util.Map;

public class CommandProcessor {
    private final Map<Command, CommandExecutor> executors;

    private Map<String, Link> commandLinks = new HashMap<>();
    private String[] args;
    private int currentArgIndex;

    public CommandProcessor(Map<Command, CommandExecutor> executors) {
         this.executors = executors;
    }

    public String[] getArgs() {
        return args;
    }

    private Command getCurrentCommand () {
        return Command.valueOf(args[currentArgIndex]);
    }

    public Link getCurrentLink () {
        Command command = getCurrentCommand();
        if (! commandLinks.containsKey(command.name())){
            throw new IllegalArgumentException("No link for command: " + command);
        }
        return commandLinks.get(command.name());
    }
    public int getCurrentArgIndex() {
        return currentArgIndex;
    }

    public void setCurrentArgIndex(int currentArgIndex) {
        this.currentArgIndex = currentArgIndex;
    }

   public String executeCommands (String[] argsIn) {
        // just make sure no previous state in case of testing
        commandLinks.clear();
        String result = null;

        args = argsIn;

        for (currentArgIndex = 0; currentArgIndex< args.length; currentArgIndex++){
            CommandExecutor executor = executors.get(getCurrentCommand());
            result = executor.executeCommand(this);
            if (null != result) {
                System.out.println(result);
            }
        }

        return result;
    }

    public void setCommandLinks(Map<String, Link> commandLinks) {
        this.commandLinks = commandLinks;
    }
}
