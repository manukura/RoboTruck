package com.kiwican.truckRobot.model;

public enum Direction {
    NORTH {
        @Override
        public Position move(Position position, GridTable gridTable) {
            return gridTable.createPosition(position.x(), position.y() + 1);
        }

        @Override
        public Direction left() {
            return WEST;
        }

        @Override
        public Direction right() {
            return EAST;
        }
    },
    EAST {
        @Override
        public Position move(Position position, GridTable gridTable) {
            return gridTable.createPosition(position.x() + 1, position.y());
        }

        @Override
        public Direction left() {
            return NORTH;
        }

        @Override
        public Direction right() {
            return SOUTH;
        }
    },
    SOUTH {
        @Override
        public Position move(Position position, GridTable gridTable) {
            return gridTable.createPosition(position.x(), position.y() - 1);
        }

        @Override
        public Direction left() {
            return EAST;
        }

        @Override
        public Direction right() {
            return WEST;
        }
    },
    WEST {
        @Override
        public Position move(Position position, GridTable gridTable) {
            return gridTable.createPosition(position.x() - 1, position.y());
        }

        @Override
        public Direction left() {
            return SOUTH;
        }

        @Override
        public Direction right() {
            return NORTH;
        }
    },
    ;
    
    abstract public Position move(Position position, GridTable gridTable);
    abstract public Direction left();
    abstract public Direction right();

    }
