package com.kiwican.truckRobot;

import com.kiwican.truckRobot.executor.CommandExecutor;
import com.kiwican.truckRobot.executor.CommandProcessor;
import com.kiwican.truckRobot.executor.GetExecutor;
import com.kiwican.truckRobot.executor.PostExecutor;
import com.kiwican.truckRobot.executor.PutExecutor;
import com.kiwican.truckRobot.model.Command;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestClient;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class TruckRobotConfig {

    @Bean
    public RestClient restClient() {
        return RestClient.create();
    }

    @Bean
    public CommandProcessor commandProcessor (PostExecutor postExecutor, GetExecutor getExecutor, PutExecutor putExecutor) {
        Map<Command, CommandExecutor> executorMap = new HashMap<>();
        executorMap.put(Command.PLACE, postExecutor);
        executorMap.put(Command.REPORT, getExecutor);
        executorMap.put(Command.LEFT, putExecutor);
        executorMap.put(Command.RIGHT, putExecutor);
        executorMap.put(Command.MOVE, putExecutor);

        return new CommandProcessor(executorMap);
    }
}
