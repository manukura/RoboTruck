# Truck Robot Command Line Application

This repository contains a simple command line client to interact
with the Truck Robot Rest Application.

It will interpret a series of commands that are provided
as program arguments at the start of the application.

It will then interpret these instructions and make the 
necessary calls to the service.

The calls that are recognised are:
PLACE,
MOVE,
LEFT,
RIGHT,
REPORT

The REPORT command will cause the current situation of the truck to be output to stdOut.

To build the repo, run the command mvn package.

This will cause a jar file to be generated in the target directory.

Then the code can be executed from the command line by typing:
java -jar *\<path to jarFile>* command list.