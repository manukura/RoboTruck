package com.kiwican.truckRobot.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TruckTest {

    private PositionFactory positionFactory = new PositionFactory(5, 5);

    @Test
    public void testCreateMoveReport(){
        Truck truck = new Truck(3, positionFactory.createPosition(3,4), Direction.EAST);
        assertEquals ("3,4,EAST", truck.report());

        truck.move(positionFactory);
        assertEquals("4,4,EAST", truck.report());
    }
}