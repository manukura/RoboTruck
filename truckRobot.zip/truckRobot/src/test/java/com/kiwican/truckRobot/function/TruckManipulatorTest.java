package com.kiwican.truckRobot.function;

import com.kiwican.truckRobot.model.Direction;
import com.kiwican.truckRobot.model.PositionFactory;
import com.kiwican.truckRobot.model.Truck;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;

import static org.junit.jupiter.api.Assertions.assertEquals;

@DataJpaTest
class TruckManipulatorTest {
    @TestConfiguration
    static class TruckManipulatorTestConfiguration {

        @Bean
        public PositionFactory gridTable() {
            return new PositionFactory(5, 5);
        }

        @Bean
        public TruckManipulator truckManipulator(PositionFactory positionFactory, TruckRepository truckRepository) {
            return new TruckManipulator(positionFactory, truckRepository);
        }
    }

    @Autowired
    private TruckManipulator manipulator;

    @Test
    public void northMove() {
        Truck truck = manipulator.place(0, 0, Direction.NORTH);
        manipulator.move(truck.getTruckId());
        assertEquals("0,1,NORTH", manipulator.fetch(truck.getTruckId()).report());
    }

    @Test
    public void testNorthTurn() {
        Truck truck = manipulator.place(0, 0, Direction.NORTH);
        manipulator.left(truck.getTruckId());
        assertEquals("0,0,WEST", manipulator.fetch(truck.getTruckId()).report());
    }

    @Test
    public void testTopNorth() {
        Truck truck = manipulator.place(3, 5, Direction.NORTH);
        manipulator.move(truck.getTruckId());
        assertEquals ("3,4,NORTH", manipulator.fetch(truck.getTruckId()).report());
    }

    @Test
    public void testMultipleMove() {
        Truck truck = manipulator.place(1,2,Direction.EAST);
        manipulator.move(truck.getTruckId());
        manipulator.move(truck.getTruckId());
        manipulator.left(truck.getTruckId());
        manipulator.move(truck.getTruckId());
        assertEquals("3,3,NORTH", manipulator.fetch(truck.getTruckId()).report());
    }
}