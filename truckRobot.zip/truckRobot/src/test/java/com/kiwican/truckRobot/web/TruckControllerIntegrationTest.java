package com.kiwican.truckRobot.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kiwican.truckRobot.exception.NotFoundException;
import com.kiwican.truckRobot.function.TruckManipulator;
import com.kiwican.truckRobot.model.Direction;
import com.kiwican.truckRobot.model.Position;
import com.kiwican.truckRobot.model.Truck;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.BDDMockito.given;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(SpringExtension.class)
@WebMvcTest(TruckController.class)
class TruckControllerIntegrationTest {
    @Autowired
    private MockMvc mvc;

    @MockitoBean
    private TruckManipulator manipulator;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    public void testGet() throws Exception {
        given(manipulator.fetch(Mockito.eq(42L)))
                .willReturn(new Truck(42L, new Position(2, 2), Direction.EAST));

        MvcResult result = mvc.perform(get("/truck/42"))
                .andExpect(status().isOk())
                .andReturn();

        Truck truck = objectMapper.readValue(result.getResponse().getContentAsString(), Truck.class);
        assertEquals("2,2,EAST", truck.report());
    }

    @Test
    public void testGetNotExist() throws Exception {
        given(manipulator.fetch(Mockito.anyLong())).willThrow(new NotFoundException());

        mvc.perform(get("/truck/42")).andExpect(status().isNotFound());
    }

    @Test
    public void testPlace() throws Exception {
        given(manipulator.place(4, 2, Direction.WEST))
                .willReturn(new Truck(42L, new Position(4, 2), Direction.WEST));

        MvcResult result = mvc.perform(post("/truck/place?x=4&y=2&direction=WEST"))
                .andExpect(status().isCreated()).andReturn();

        Truck truck = objectMapper.readValue(result.getResponse().getContentAsString(), Truck.class);
        assertEquals ("4,2,WEST", truck.report());
        assertEquals(42L, truck.getTruckId());
    }

    @Test
    public void testLeft() throws Exception {
        given(manipulator.left(Mockito.eq(42L)))
                .willReturn(new Truck(42L, new Position(2, 2), Direction.EAST));

        MvcResult result = mvc.perform(put("/truck/update/42?updateType=LEFT"))
                .andExpect(status().isOk()).andReturn();
        Truck truck = objectMapper.readValue(result.getResponse().getContentAsString(), Truck.class);
        assertEquals ("2,2,EAST", truck.report());
        assertEquals(42L, truck.getTruckId());
    }

    @Test
    public void testRight() throws Exception {
        given(manipulator.right(Mockito.eq(42L)))
                .willReturn(new Truck(42L, new Position(2, 2), Direction.EAST));

        MvcResult result = mvc.perform(put("/truck/update/42?updateType=RIGHT"))
                .andExpect(status().isOk()).andReturn();
        Truck truck = objectMapper.readValue(result.getResponse().getContentAsString(), Truck.class);
        assertEquals ("2,2,EAST", truck.report());
        assertEquals(42L, truck.getTruckId());
    }

    @Test
    public void testMove() throws Exception {
        given(manipulator.move(Mockito.eq(42L)))
                .willReturn(new Truck(42L, new Position(2, 2), Direction.EAST));

        MvcResult result = mvc.perform(put("/truck/update/42?updateType=MOVE"))
                .andExpect(status().isOk()).andReturn();
        Truck truck = objectMapper.readValue(result.getResponse().getContentAsString(), Truck.class);
        assertEquals ("2,2,EAST", truck.report());
        assertEquals(42L, truck.getTruckId());
    }
}