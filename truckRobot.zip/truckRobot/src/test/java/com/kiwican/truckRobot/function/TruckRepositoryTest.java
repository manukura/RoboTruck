package com.kiwican.truckRobot.function;

import com.kiwican.truckRobot.exception.NotFoundException;
import com.kiwican.truckRobot.model.Direction;
import com.kiwican.truckRobot.model.Position;
import com.kiwican.truckRobot.model.Truck;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@DataJpaTest
class TruckRepositoryTest {
    @Autowired
    TruckRepository truckRepository;

    public static final int X = 3;
    public static final int Y = 2;
    public static final Direction DIRECTION = Direction.EAST;

    @Test
    public void testCreateAndFetch () {
        Truck truck = new Truck(new Position(X, Y), DIRECTION);
        Truck inserted = truckRepository.save(truck);

        Truck saved = truckRepository.findOrThrow(inserted.getTruckId());

        assertEquals(X, saved.getPosition().x());
        assertEquals(Y, saved.getPosition().y());
        assertEquals(DIRECTION, saved.getDirection());
        assertEquals(inserted.getTruckId(), saved.getTruckId());
    }

    @Test
    void testNotExist() {
        Exception exception = assertThrows(NotFoundException.class, () -> {
            Truck truck = truckRepository.findOrThrow(42L);
        });

        assertEquals("Cannot find truck with truckId: 42", exception.getMessage());
    }
}