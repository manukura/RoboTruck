package com.kiwican.truckRobot.model;

import org.junit.jupiter.api.Test;

import static com.kiwican.truckRobot.model.Direction.EAST;
import static com.kiwican.truckRobot.model.Direction.NORTH;
import static com.kiwican.truckRobot.model.Direction.SOUTH;
import static com.kiwican.truckRobot.model.Direction.WEST;
import static org.junit.jupiter.api.Assertions.assertEquals;

class DirectionTest {

    private final PositionFactory positionFactory = new PositionFactory(5, 5);

    @Test
    public void testNorth () {
        executeMoveTest(NORTH, 0, 0, 0, 1);
        executeMoveTest(NORTH, 4, 4, 4, 4);
        assertEquals(EAST, NORTH.right());
        assertEquals(WEST, NORTH.left());
    }

    @Test
    public void testSouth () {
        executeMoveTest(SOUTH, 0, 0, 0, 0);
        executeMoveTest(SOUTH, 4, 4, 4, 3);
        assertEquals(EAST, SOUTH.left());
        assertEquals(WEST, SOUTH.right());
    }

    @Test
    public void testEast () {
        executeMoveTest(EAST, 0, 0, 1, 0);
        executeMoveTest(EAST, 4, 4, 4, 4);
        assertEquals(SOUTH, EAST.right());
        assertEquals(NORTH, EAST.left());
    }

    @Test
    public void testWest () {
        executeMoveTest(WEST, 0, 0, 0, 0);
        executeMoveTest(WEST, 4, 4, 3, 4);
        assertEquals(SOUTH, WEST.left());
        assertEquals(NORTH, WEST.right());
    }

    private void executeMoveTest(Direction direction, int currentX, int currentY, int expectedX, int expectedY) {
        Position result = direction.move(new Position(currentX, currentY), positionFactory);
        assertEquals (new Position(expectedX, expectedY), result);
    }
}