package com.kiwican.truckRobot.function;

import com.kiwican.truckRobot.model.PositionFactory;
import com.kiwican.truckRobot.model.Position;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PositionFactoryTest {

    private static final int X_SQUARES = 5;
    private static final int Y_SQUARES = 5;

    private PositionFactory candidate;

    @BeforeEach
    public void init() {
        candidate = new PositionFactory(X_SQUARES, Y_SQUARES);
    }

    @Test
    public void test0And0() {
        executeTest(0, 0, 0, 0);
    }

    @Test
    void testMinus1And0() {
        executeTest(-1, 0, 0, 0);
    }

    @Test
    void test3AndMinus1() {
        executeTest(3, -1, 3, 0);
    }

    @Test
    void test6And4() {
        executeTest(6, 4, 4, 4);
    }

    @Test
    void test4and10() {
        executeTest(4, 10, 4, 4);
    }

    private void executeTest(int suppliedX, int suppliedY, int expectedX, int expectedY) {
        Position result = candidate.createPosition(suppliedX, suppliedY);
        assertEquals(new Position(expectedX, expectedY), result);
    }
}