package com.kiwican.truckRobot.web;

import com.kiwican.truckRobot.function.TruckManipulator;
import com.kiwican.truckRobot.model.Direction;
import com.kiwican.truckRobot.model.Truck;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import static com.kiwican.truckRobot.web.UpdateType.LEFT;
import static com.kiwican.truckRobot.web.UpdateType.MOVE;
import static com.kiwican.truckRobot.web.UpdateType.RIGHT;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

@RestController
@RequestMapping("/truck")
public class TruckController {

    private final TruckManipulator manipulator;

    @Autowired
    public TruckController(TruckManipulator manipulator) {
        this.manipulator = manipulator;
    }

    @GetMapping("/{truckId}")
    public Truck fetchTruck (@PathVariable long truckId) {
        Truck truck = manipulator.fetch(truckId);
        addLinks(truck);
        return truck;
    }

    @PostMapping("/place")
    @ResponseStatus(HttpStatus.CREATED)
    public Truck place (@RequestParam int x, @RequestParam int y, @RequestParam Direction direction) {
        Truck result = manipulator.place(x,y,direction);
        addLinks(result);
        return result;
    }

    private static void addLinks(Truck result) {
        if (! result.hasLinks()) {
            result.add(linkTo(TruckController.class).slash(result.getTruckId()).withSelfRel(),
                    linkTo(TruckController.class).slash(result.getTruckId()).withRel("REPORT"),
                    linkTo(methodOn(TruckController.class).update(result.getTruckId(), LEFT)).withRel(LEFT.name()),
                    linkTo(methodOn(TruckController.class).update(result.getTruckId(), RIGHT)).withRel(RIGHT.name()),
                    linkTo(methodOn(TruckController.class).update(result.getTruckId(), MOVE)).withRel(MOVE.name())
            );
        }
    }

    @PutMapping("/update/{truckId}")
    @ResponseStatus(HttpStatus.OK)
    public Truck update (@PathVariable long truckId, @RequestParam UpdateType updateType) {
        Truck truck = updateType.executeUpdate(truckId, manipulator);
        addLinks(truck);
        return truck;
    }
}
