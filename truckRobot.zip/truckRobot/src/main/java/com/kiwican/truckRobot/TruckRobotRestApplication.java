package com.kiwican.truckRobot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TruckRobotRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(TruckRobotRestApplication.class, args);
	}

}
