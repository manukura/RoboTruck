package com.kiwican.truckRobot.web;

import com.kiwican.truckRobot.function.TruckManipulator;
import com.kiwican.truckRobot.model.Truck;

public enum UpdateType {
    LEFT {
        @Override
        public Truck executeUpdate(long truckId, TruckManipulator manipulator) {
            return manipulator.left(truckId);
        }
    },
    RIGHT {
        @Override
        public Truck executeUpdate(long truckId, TruckManipulator manipulator) {
            return manipulator.right(truckId);
        }
    },
    MOVE {
        @Override
        public Truck executeUpdate(long truckId, TruckManipulator manipulator) {
            return manipulator.move(truckId);
        }
    },
    ;
    abstract public Truck executeUpdate (long truckId, TruckManipulator manipulator);
}
