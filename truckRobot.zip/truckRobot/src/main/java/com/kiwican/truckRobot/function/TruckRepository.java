package com.kiwican.truckRobot.function;

import com.kiwican.truckRobot.exception.NotFoundException;
import com.kiwican.truckRobot.model.Truck;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TruckRepository extends JpaRepository<Truck, Long> {
    default Truck findOrThrow (Long truckId) {
        Optional<Truck> truck = findById(truckId);
        return truck.orElseThrow(() -> new NotFoundException("Cannot find truck with truckId: " + truckId));
    }
}
