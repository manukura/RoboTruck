package com.kiwican.truckRobot.function;

import com.kiwican.truckRobot.model.Direction;
import com.kiwican.truckRobot.model.PositionFactory;
import com.kiwican.truckRobot.model.Truck;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class TruckManipulator {
    private final PositionFactory positionFactory;
    private final TruckRepository truckRepository;

    @Autowired
    public TruckManipulator(PositionFactory positionFactory, TruckRepository truckRepository) {
        this.positionFactory = positionFactory;
        this.truckRepository = truckRepository;
    }

    public Truck place(int x, int y, Direction direction) {
        Truck newTruck = truckRepository.save(new Truck(positionFactory.createPosition(x, y), direction));
        return newTruck;
    }

    public Truck left(long truckId) {
        Truck truck = fetch(truckId);
        truck.left();
        return truckRepository.save(truck);
    }

    public Truck right(long truckId) {
        Truck truck = fetch(truckId);
        truck.right();
        return truckRepository.save(truck);
    }

    public Truck move(long truckId) {
        Truck truck = fetch(truckId);
        truck.move(positionFactory);
        return truckRepository.save(truck);
    }

    public Truck fetch(long truckId) {
        return  truckRepository.findOrThrow(truckId);
    }
}
