package com.kiwican.truckRobot.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * The grid of possible positions for the truck.
 * It starts at the South West most corner and extends MaxX sectors to the right and MaxY sectors to the top
 */
@Component
public class PositionFactory {
    private final int maxX;
    private final int maxY;

    public PositionFactory(@Value("${xSquares}") int xSquares, @Value("${ySquares}") int ySquares) {
        this.maxX = xSquares - 1;
        this.maxY = ySquares - 1;
    }

    /**
     * Creates a new Position record that is within the bounds of the board.
     * If the co-ordinates provided are off the board, the new position will be the
     * closest point on the board
     */
    public Position createPosition(int x, int y) {
        int newX = Math.max (0, Math.min (maxX, x));
        int newY = Math.max (0, Math.min (maxY, y));
        return new Position(newX, newY);
    }
}
