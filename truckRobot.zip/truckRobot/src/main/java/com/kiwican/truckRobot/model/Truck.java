package com.kiwican.truckRobot.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Entity;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Transient;
import org.springframework.hateoas.RepresentationModel;
import org.springframework.hateoas.Link;

import java.util.Map;
import java.util.Objects;

@Entity
public class Truck extends RepresentationModel<Truck> {

    private Long truckId;
    private Position position;
    private Direction direction;

    public Truck(){
    }

    public Truck (Position position, Direction direction) {
        this.position = position;
        this.direction = direction;
    }

    public Truck(long truckId, Position position, Direction direction) {
        this.truckId = truckId;
        this.position = position;
        this.direction = direction;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public Long getTruckId() {
        return truckId;
    }

    public void setTruckId(Long truckId) {
        this.truckId = truckId;
    }

    @Transient
    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    @JsonIgnore
    public int getX () {
        return null == position ? -1 : position.x();
    }

    public void setX (int x) {
        position = new Position(x, null == position ? -1 : position.y());
    }

    @JsonIgnore
    public int getY () {
        return null == position ? -1 : position.y();
    }

    public void setY (int y) {
        position = new Position(null == position ? -1 : position.x(), y);
    }

    @Enumerated
    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    // required because no setter in superclass prevents jackson deserializing
    @JsonProperty("_links")
    public void setLinks(final Map<String, Link> links) {
        links.forEach((label, link) ->  add(link.withRel(label)) );
    }

    @Override
    public String toString() {
        return "Truck{" +
                "truckId=" + truckId +
                ", position=" + position +
                ", direction=" + direction +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Truck other = (Truck) o;
        return Objects.equals(truckId, other.truckId);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(truckId);
    }

    // commands
    public void move (PositionFactory positionFactory) {
        position = direction.move(position, positionFactory);
    }

    public void left () {
        direction = direction.left();
    }

    public void right() {
        direction = direction.right();
    }

    public String report() {
        return String.format("%d,%d,%s", position.x(), position.y(),direction);
    }
}
