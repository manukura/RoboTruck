package com.kiwican.truckRobot.model;

public record Position(int x, int y) {

    public Position move(int deltaX, int deltaY, PositionFactory factory) {
        return factory.createPosition(x + deltaX, y + deltaY);
    }
}
