# Truck Robot Rest Application

This repository contains the code to implement a Truck Robot Rest Application.
It is based in SpringBoot and maintains state through an in-memory database.

As it was an exercise, there is no security provided.

The REST interface is described in the Swagger file: src/main/resources/static/TruckRobotRestApplicationSwagger.html

Once the new truck has been created, the other links that can  be used
to manipulate the truck are provided in the response.

To run this service, execute the command mvn spring-boot:run
This will build and start the service.  It will attach to the default port of 8080

src/main/resources/application.properties contains some configuration properties
for the application, including the size of the grid used.

For convenience, a set of Postman tests are located in the file:
src/main/resources/static/Truck Robot Tests.postman_collection.json